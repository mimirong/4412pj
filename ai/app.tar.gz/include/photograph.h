#ifndef _PHOTOGRAPH_H
#define _PHOTOGRAPH_H

//void *photo(void *buf);
void photograph(char *buff);

#endif
