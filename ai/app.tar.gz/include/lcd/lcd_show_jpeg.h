#ifndef _LCD_SHOW_JPED_H
#define _LCD_SHOW_JPED_H

int show_jpeg(char *path);

#endif
